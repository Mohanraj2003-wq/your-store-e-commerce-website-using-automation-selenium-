# E-Commerce-Website-Automation [Selenium + Python]


<img src='./pictures/YT.PNG' width=50> Youtube reference: https://www.youtube.com/watch?v=e9Bf769mXu0

-----------------------------------------------------------------------------------------------------


In this project, we will simulate and automate a purchase scenario from an E-Commerce- Website with Selenium & Python.


<img src='./pictures/Selenium_Python.jpeg' width=500>

The goal is to buy different electronic devices, select the delivery date and complete the checkout process.
--------------------------------------------

<img src='./pictures/ecom_1.PNG' width=500>
<img src='./pictures/ecom_2.PNG' width=500>
<img src='./pictures/ecom_3.PNG' width=500>
